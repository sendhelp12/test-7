# Validation for 2.2.4-mfg-experimental.3

## Earlier experimental.1 evidence

The previous experimental.1 build was compiled in the user's Windows GitHub
Actions environment and launched in Dark Souls III using D3D11. The experimental.1
log reports requested=4x, runtime_max_generated=3, active=4x, fallback=0,
successful FrameGeneration creation, a 240 Hz timer and an asynchronous
presenter. The adaptive governor is disabled and performance telemetry enabled.

Thirteen samples from 20:13:50 through 20:14:50, after switching input to
1920x1080 with 3840x2160 output:

| Measurement | Minimum | Median | Maximum |
| --- | ---: | ---: | ---: |
| Generated-to-real interval (ms) | 4.914 | 4.969 | 5.159 |
| Real-to-next-generated interval (ms) | 32.326 | 34.734 | 36.081 |
| NR GPU time (ms) | 28.945 | 30.160 | 31.275 |
| DLSS SR GPU time (ms) | 4.302 | 4.754 | 5.086 |
| FG GPU time reported (ms) | 5.772 | 6.092 | 6.597 |
| Game/source FPS | 112 | 120 | 120 |
| Proxy output FPS | 76 | 80 | 85 |

Interval fields summarize accepted Present calls, not physical scanout. GPU
timings on different phases/queues are not an independently measured end-to-end
latency. The retained 1.6-second peak includes a resolution transition and is
not evidence of a recurring gameplay stall.

## Experimental.2 runtime evidence and experimental.3 regression

The user then compiled and ran experimental.2. `standalone-dlssnr(3).log`
confirms the new build and active cadence pacing. Twelve later 1080p-input
samples from 20:51:01 through 20:51:56 have these medians:

| Measurement | Median |
| --- | ---: |
| Generated-to-real interval (ms) | 12.187 |
| Real-to-next-generated interval (ms) | 12.971 |
| NR GPU time (ms) | 30.099 |
| Proxy output FPS | 81 |
| NGX-submit-to-presentation-entry delay (ms) | 48.616 |

In six earlier near-native samples from 20:50:11 through 20:50:36, the last
metric has a 194.093 ms median (105.873–203.382 ms range). The older capture's
near-native samples were approximately 53 ms. This metric includes processing
and queued time before the presentation function; it is not physical input
latency. Actual Present calls often take 2–3.5 ms in this part of the new log.

Source inspection identified a remaining false-overrun condition: the old
threshold was half a physical refresh even when the adaptive output interval
was much longer. That unnecessarily reset otherwise valid output deadlines.

A new test using 2.1/3.6/6 ms drawing/Present costs at a 50 ms group cadence
fails on experimental.2. It passes after changing the threshold to the whole
output interval, as does a test where work takes exactly one refresh. Existing
late-overrun behavior, mode changes, recovery and jitter checks also pass.
The actual wait/accept functions pass against the simulated timer using a
3.6 ms Present cost. These executed checks use strict compiler warnings and
undefined-behavior instrumentation.

The growing-delay behavior is demonstrated in the simulated scheduler. Its
contribution to the real runtime delay is an inference consistent with the
log, and the effect of experimental.3 still requires in-game verification.

## Checks retained and rerun as relevant

- Compiled and ran the actual FrameGroupPacer helper tests with g++, strict
  warnings and undefined-behavior instrumentation. Covered 2x/3x/4x at about
  20 groups/s; 30 real FPS at 4x on 240 Hz; full-refresh production; jitter;
  sustained slowdown and recovery; bounded backlog; long pauses; invalid
  timestamps; mode changes; and late-deadline reanchoring.
- Confirmed that 50 ms production with four outputs settles at 12.5 ms between
  outputs in simulation, including group boundaries. Drawing/Present overhead that fits the output interval does not accumulate
  per output.
- Extracted the actual WaitForExplicitProxyPacing and RecordAcceptedProxyPresent
  functions and compiled them against a simulated QPC/Windows timer backend.
  Checked adaptive timer selection, group-boundary intervals, stop handling
  before future and overdue deadlines, overrun recovery, and refresh fallback.
- Ran the existing actual NGX group-recorder checks against a simulated
  Direct3D/NGX backend. These validate recording order and state restoration,
  not driver execution.
- Checked producer timestamp propagation through direct, staged and inline
  presentation independently of diagnostic telemetry.
- Checked that the existing async activation condition, FG fence deadlines,
  texture ownership and slot-reclamation functions are retained.
- Regenerated the cumulative diff, verified application to the supplied base
  reproduces the overlay, and matched the workflow checksum to the ZIP.

The Windows script also compiles and runs the frame-group and pacing helper
checks with MSVC before compiling the add-on.

## Limits

Experimental.3 has not been compiled with MSVC here or run on a Windows/NVIDIA
GPU. The user's successful builds and runtime logs concern experimental.1 and
experimental.2. The .3 change is limited to the pacing threshold, version
identifier, tests and documentation; texture ownership and GPU fence rules
were not modified.

Simulations do not model DWM, DXGI flip selection, GPU synchronization, driver
scheduling, VRR, image quality, HDR, resizing or 32-bit carrier behavior. Longer
pacing waits retain existing presentation slots for longer. Fence/state rules
are preserved, but actual runtime behavior still needs testing. The estimator
cannot predict an unexpected future stall. This update does not increase NR
throughput or implement Reflex.

The uploaded FG runtime's version metadata is 310.8.0.0; SHA-256:

```text
5d5cbf14d2727d47f93fd10bf77bd91708ae122482a6f86fd564971641ebd47b
```

The runtime reports a three-generated-frame maximum in the supplied log.
Successful evaluation does not prove distinct, valid interpolated images.
The optional DLSSG.OutputDisableInterpolation resource remains outside the
existing integration. No NVIDIA runtime DLLs are included in this package.
