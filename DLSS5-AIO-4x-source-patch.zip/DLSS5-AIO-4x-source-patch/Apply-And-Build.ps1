[CmdletBinding()]
param(
    [string]$SourceDirectory,
    [switch]$Include32Bit
)

$ErrorActionPreference = 'Stop'
$patchDirectory = $PSScriptRoot

function Assert-NativeSuccess([string]$Action) {
    if ($LASTEXITCODE -ne 0) { throw "$Action failed (exit code $LASTEXITCODE)." }
}

function Get-NormalizedSha256([string]$Path) {
    $text = [IO.File]::ReadAllText($Path).Replace("`r`n", "`n")
    $hash = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($text)
        return [BitConverter]::ToString($hash.ComputeHash($bytes)).Replace('-', '').ToLowerInvariant()
    } finally { $hash.Dispose() }
}

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw 'Git for Windows is required to obtain the original build dependencies.'
}

if ([string]::IsNullOrWhiteSpace($SourceDirectory)) {
    $buildsDirectory = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'DLSS5-AIO-Custom-Builds'
    $SourceDirectory = Join-Path $buildsDirectory ('mfg-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $buildsDirectory -Force | Out-Null
    Write-Host 'Downloading AIO v2.2.4 and its pinned submodules into a new build folder...'
    & git -c core.autocrlf=false clone --branch v2.2.4 --depth 1 --recurse-submodules `
        'https://github.com/kibblerz/DLSS5-Reshade-AIO.git' $SourceDirectory
    Assert-NativeSuccess 'Downloading the original source'
} else {
    $SourceDirectory = (Resolve-Path -LiteralPath $SourceDirectory).Path
}

$expected = Get-Content -LiteralPath (Join-Path $patchDirectory 'base-source-sha256.json') -Raw | ConvertFrom-Json
foreach ($entry in $expected.PSObject.Properties) {
    $target = Join-Path $SourceDirectory $entry.Name
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing base source: $target" }
    if ((Get-NormalizedSha256 $target) -ne $entry.Value) {
        throw "Base source differs from the uploaded v2.2.4 ZIP: $($entry.Name). No patch files have been applied. Use a clean matching checkout."
    }
}

$dependency = Join-Path $SourceDirectory 'external\DLSS5-Feeder\tools\vcvars.bat'
if (-not (Test-Path -LiteralPath $dependency)) {
    throw 'The DLSS5-Feeder submodule is incomplete. Run git submodule update --init --recursive in the checkout, then retry.'
}

$overlay = Join-Path $patchDirectory 'overlay'
$overlayFiles = @(Get-ChildItem -LiteralPath $overlay -Recurse -File)
# Verify new paths before any copying, so unrelated additions are preserved.
foreach ($file in $overlayFiles) {
    $relative = $file.FullName.Substring($overlay.Length).TrimStart([char[]]'\/')
    $key = $relative.Replace('\', '/')
    $target = Join-Path $SourceDirectory $relative
    if ($null -eq $expected.PSObject.Properties[$key] -and (Test-Path -LiteralPath $target)) {
        throw "A new patch path already exists: $relative. No patch files have been applied."
    }
}
foreach ($file in $overlayFiles) {
    $relative = $file.FullName.Substring($overlay.Length).TrimStart([char[]]'\/')
    $target = Join-Path $SourceDirectory $relative
    New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $file.FullName -Destination $target
}

Push-Location -LiteralPath $SourceDirectory
try {
    Write-Host 'Building and running the frame-group checks...'
    & cmd.exe /d /c 'tools\tests\build-frame-generation-test.bat'
    Assert-NativeSuccess 'The frame-group checks'
    Write-Host 'Building the experimental x64 add-on...'
    & cmd.exe /d /c 'addon\build.bat'
    Assert-NativeSuccess 'The x64 add-on build'
    if ($Include32Bit) {
        & cmd.exe /d /c 'x86-host\build-carrier.bat'
        Assert-NativeSuccess 'The x86 wrapper and carrier build'
    }
} finally { Pop-Location }

Write-Host ''
Write-Host 'Build complete. The new add-on is:'
Write-Host (Join-Path $SourceDirectory 'addon\build\standalone-dlssnr.addon64')
Write-Host 'Back up your working add-on before replacing it. Keep your existing runtime DLLs.'
Write-Host 'In ReShade, select Frame generation multiplier, choose 4x, then restart the game.'
Write-Host 'The active count will be limited by the runtime and GPU; this does not unlock unsupported hardware.'
