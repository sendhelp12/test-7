#include "../../addon/include/frame-generation-pacing.hpp"

#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

using dlss5_aio_fg::FrameGroupPacer;
using Tick = FrameGroupPacer::Tick;
static constexpr Tick frequency = 1000000; // microseconds
static constexpr Tick refresh = 4167;      // 240 Hz

struct Simulation
{
    FrameGroupPacer pacer;
    Tick submitted = 1000000;
    Tick consumer = 0;
    Tick previous_present = 0;
    std::vector<Tick> gaps;
    Tick worst_backlog = 0;

    void Group(Tick period, unsigned int count, Tick draw_cost = 400)
    {
        submitted += period;
        const Tick ready = submitted + period;
        consumer = std::max(consumer, ready);
        worst_backlog = std::max(worst_backlog, consumer - ready);
        pacer.BeginGroup(count, submitted, consumer, frequency, refresh);
        for (unsigned int i = 0; i < count; ++i)
        {
            consumer = std::max(consumer, pacer.Deadline()) + draw_cost;
            if (previous_present > 0) gaps.push_back(consumer - previous_present);
            previous_present = consumer;
            pacer.Accepted(consumer);
        }
    }
};

int main()
{
    // Reproduce the log's roughly 20 completed groups/s. Four equally spaced
    // outputs must be ~12.5 ms apart, including across group boundaries. At the
    // same production rate, 2x and 3x must choose their own longer intervals.
    for (unsigned int count : {2u, 3u, 4u})
    {
        Simulation sim;
        for (int i = 0; i < 2000; ++i) sim.Group(50000, count);
        const Tick expected = (50000 + count - 1) / count;
        for (std::size_t i = count * 3; i < sim.gaps.size(); ++i)
            assert(sim.gaps[i] >= expected - 2 && sim.gaps[i] <= expected + 2);
        // Draw/Present time must not accrue once per output on the deadline.
        assert(sim.worst_backlog < 5000);
    }

    // 30 real fps at 4x needs ~8.33 ms, including on a 240 Hz monitor.
    Simulation thirty;
    for (int i = 0; i < 100; ++i) thirty.Group(33332, 4);
    for (std::size_t i = 12; i < thirty.gaps.size(); ++i)
        assert(thirty.gaps[i] == 8333);

    // At the monitor's full group rate, rendering overhead fits inside the
    // absolute deadline. A full extra refresh is not added after each draw.
    Simulation at_refresh;
    for (int i = 0; i < 1000; ++i) at_refresh.Group(refresh * 4, 4);
    for (std::size_t i = 12; i < at_refresh.gaps.size(); ++i)
        assert(at_refresh.gaps[i] == refresh);

    // The experimental.2 runtime capture shows ordinary Present calls taking
    // roughly 3 ms in the near-native section. Those fit inside an adaptive
    // 12.5 ms output interval. Treating them as refresh/2 overruns accumulated
    // extra waits and allowed completed groups to back up in the output ring.
    for (Tick draw_cost : {Tick{2100}, Tick{3600}, Tick{6000}})
    {
        Simulation slow_present;
        for (int i = 0; i < 1000; ++i) slow_present.Group(50000, 4, draw_cost);
        for (std::size_t i = 12; i < slow_present.gaps.size(); ++i)
            assert(slow_present.gaps[i] == 12500);
        assert(slow_present.worst_backlog < 5000);
    }
    // Work that fits exactly inside a refresh interval also fits the schedule;
    // it must not acquire a second complete wait after Present returns.
    Simulation expensive_refresh;
    for (int i = 0; i < 1000; ++i)
        expensive_refresh.Group(refresh * 4, 4, refresh);
    for (std::size_t i = 12; i < expensive_refresh.gaps.size(); ++i)
        assert(expensive_refresh.gaps[i] == refresh);
    assert(expensive_refresh.worst_backlog < 5000);

    // Fast submissions never ask the monitor to display faster than refresh.
    FrameGroupPacer fast;
    fast.BeginGroup(4, 1000000, 1001000, frequency, refresh);
    fast.BeginGroup(4, 1002000, 1003000, frequency, refresh);
    assert(fast.Interval() == refresh);

    // Adapt to a persistent slowdown, then recover promptly when the producer
    // becomes faster. The fixed-size output ring must not acquire a growing
    // queue simply because old timing estimates remain in force.
    Simulation changing;
    for (int i = 0; i < 100; ++i) changing.Group(25000, 4);
    for (int i = 0; i < 100; ++i) changing.Group(60000, 4);
    assert(changing.pacer.Interval() == 15000);
    for (int i = 0; i < 1000; ++i) changing.Group(25000, 4);
    assert(changing.pacer.Interval() == 6250);
    assert(changing.worst_backlog < 60000);
    for (std::size_t i = changing.gaps.size() - 100; i < changing.gaps.size(); ++i)
        assert(changing.gaps[i] == 6250);

    // Modest production jitter stays bounded; all four outputs are retained.
    Simulation jitter;
    for (int i = 0; i < 1000; ++i)
        jitter.Group(50000 + (i % 5 - 2) * 500, 4);
    assert(jitter.gaps.size() == 3999);
    assert(jitter.worst_backlog < 10000);
    for (std::size_t i = 12; i < jitter.gaps.size(); ++i)
        assert(jitter.gaps[i] >= 10000 && jitter.gaps[i] <= 16000);

    // A missed deadline starts another full adaptive interval. It must not
    // discharge remaining subframes back-to-back to recover elapsed time.
    FrameGroupPacer late;
    late.BeginGroup(4, 1000000, 1050000, frequency, refresh);
    late.BeginGroup(4, 1050000, 1100000, frequency, refresh);
    const Tick accepted_late = late.Deadline() + 100000;
    late.Accepted(accepted_late);
    assert(late.Deadline() == accepted_late + 12500);

    // A long pause or nonmonotonic timestamp resets the production history.
    late.BeginGroup(4, 2100000, 2200000, frequency, refresh);
    assert(late.Samples() == 0 && late.Deadline() == 2200000);
    assert(late.Interval() == refresh);
    late.BeginGroup(4, 2050000, 2200100, frequency, refresh);
    assert(late.Samples() == 0 && late.Deadline() == 2200100);

    // Mode changes and real-only groups cannot carry a 4x deadline into 2x,
    // the overlay, a fallback frame, or a different display refresh period.
    late.BeginGroup(2, 2150000, 2250000, frequency, refresh);
    assert(late.Samples() == 0 && late.Interval() == refresh);
    late.BeginGroup(1, 2200000, 2300000, frequency, refresh);
    assert(late.Interval() == 0 && late.Deadline() == 0);
    late.BeginGroup(4, 2300000, 2350000, frequency, 8333);
    assert(late.Samples() == 0 && late.Interval() == 8333);

    // Missing metadata uses the existing refresh-timer fallback. Very slow
    // production never requests a wait longer than 50 ms per output.
    late.BeginGroup(4, 0, 2400000, frequency, refresh);
    assert(late.Interval() == 0);
    late.BeginGroup(2, 2500000, 2900000, frequency, refresh);
    late.BeginGroup(2, 2900000, 3300000, frequency, refresh);
    assert(late.Interval() <= 50000);
    late.Reset();
    assert(late.Deadline() == 0 && late.Samples() == 0);

    std::cout << "Frame-generation pacing checks passed\n";
}
