"""Exercise the actual add-on wait/accept functions with a simulated QPC timer.

Requires Python and g++ on Linux. This checks timer wiring and cancellation;
it does not simulate DXGI, GPU fences, Windows scheduling or physical scanout.
"""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = (root / "addon/src/nr-standalone.cpp").read_text()
begin = source.index("static bool WaitForExplicitProxyPacing()")
end = source.index("static unsigned int CounterDeltaMicroseconds(", begin)
functions = source[begin:end]

preamble = r'''
#include "frame-generation-pacing.hpp"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
using LONGLONG = std::int64_t;
using DWORD = unsigned long;
using HANDLE = void *;
struct LARGE_INTEGER { LONGLONG QuadPart = 0; };
constexpr bool FALSE = false;
constexpr DWORD WAIT_OBJECT_0 = 0, WAIT_TIMEOUT = 258;
int timer_handle, stop_handle;
HANDLE g_proxy_pacing_timer = &timer_handle;
HANDLE g_proxy_present_stop_event = &stop_handle;
bool g_proxy_explicit_pacing_active = true;
LONGLONG g_proxy_pacing_qpc_frequency = 1000000;
LONGLONG g_proxy_pacing_interval_qpc = 4167;
LONGLONG g_proxy_next_present_qpc = 0;
dlss5_aio_fg::FrameGroupPacer g_proxy_group_pacer;
LONGLONG clock_now = 1100000, timer_due = 0;
bool stop_requested = false, arm_succeeds = true;
unsigned long long g_proxy_pacing_late_frames = 0, g_proxy_present_timeouts = 0;
unsigned int g_cpu_proxy_pacing_wait_us = 0;
unsigned int g_proxy_output_interval_us = 0, g_proxy_output_interval_avg_us = 0;
unsigned int g_proxy_output_interval_peak_us = 0;
unsigned int g_proxy_generated_to_real_us = 0, g_proxy_real_to_generated_us = 0;
bool g_proxy_last_accepted_was_generated = false;
LARGE_INTEGER g_proxy_last_accepted_present_qpc;
bool QueryPerformanceCounter(LARGE_INTEGER *value) {
    value->QuadPart = clock_now; return true;
}
DWORD GetLastError() { return 0; }
void Log(const char *, ...) {}
unsigned int CounterDeltaMicroseconds(const LARGE_INTEGER &a, const LARGE_INTEGER &b) {
    return static_cast<unsigned int>(b.QuadPart - a.QuadPart);
}
void SmoothMicroseconds(unsigned int &value, unsigned int sample) { value = sample; }
void RecordPeakMicroseconds(unsigned int &value, unsigned int sample) {
    value = std::max(value, sample);
}
DWORD WaitForSingleObject(HANDLE handle, DWORD timeout) {
    assert(handle == g_proxy_present_stop_event && timeout == 0);
    return stop_requested ? WAIT_OBJECT_0 : WAIT_TIMEOUT;
}
bool SetWaitableTimer(HANDLE handle, LARGE_INTEGER *due, int, void *, void *, bool) {
    assert(handle == g_proxy_pacing_timer && due->QuadPart < 0);
    timer_due = clock_now + (-due->QuadPart + 9) / 10;
    return arm_succeeds;
}
DWORD WaitForMultipleObjects(unsigned int count, const HANDLE *handles, bool, DWORD timeout) {
    assert(count == 2 && handles[0] == g_proxy_present_stop_event);
    assert(handles[1] == g_proxy_pacing_timer && timeout == 50);
    if (stop_requested) return WAIT_OBJECT_0;
    if (timer_due - clock_now > static_cast<LONGLONG>(timeout) * 1000) {
        clock_now += static_cast<LONGLONG>(timeout) * 1000;
        return WAIT_TIMEOUT;
    }
    clock_now = std::max(clock_now, timer_due);
    return WAIT_OBJECT_0 + 1;
}
'''

tests = r'''
int main() {
    g_proxy_group_pacer.BeginGroup(4, 1000000, 1050000, 1000000, 4167);
    g_proxy_group_pacer.BeginGroup(4, 1050000, clock_now, 1000000, 4167);
    for (unsigned int i = 0; i < 4; ++i) {
        assert(WaitForExplicitProxyPacing());
        clock_now += 3600; // ordinary Present cost seen in the new runtime log
        RecordAcceptedProxyPresent(i != 3);
        if (i > 0) assert(g_proxy_output_interval_us == 12500);
    }
    assert(g_proxy_generated_to_real_us == 12500);
    clock_now = 1150000;
    g_proxy_group_pacer.BeginGroup(4, 1100000, clock_now, 1000000, 4167);
    assert(WaitForExplicitProxyPacing());
    clock_now += 3600;
    RecordAcceptedProxyPresent(true);
    assert(g_proxy_real_to_generated_us == 12500);

    // Stop interrupts both an upcoming wait and an already missed deadline.
    stop_requested = true;
    assert(!WaitForExplicitProxyPacing());
    clock_now += 100000;
    assert(!WaitForExplicitProxyPacing());
    stop_requested = false;
    assert(WaitForExplicitProxyPacing());
    RecordAcceptedProxyPresent(true);
    assert(g_proxy_group_pacer.Deadline() == clock_now + 12500);

    // Missing producer metadata retains the previous refresh-timer fallback.
    g_proxy_group_pacer.Reset();
    const auto before = clock_now;
    assert(WaitForExplicitProxyPacing());
    assert(clock_now == before + 4167);
    assert(g_proxy_present_timeouts == 0);
    std::cout << "Actual pacing timer integration checks passed with simulated clock\n";
}
'''

with tempfile.TemporaryDirectory(prefix="dlss5-pacing-") as temporary:
    cpp = Path(temporary) / "pacing.cpp"
    executable = Path(temporary) / "pacing"
    cpp.write_text(preamble + functions + tests)
    subprocess.run([
        "g++", "-std=c++17", "-Wall", "-Wextra", "-Wconversion", "-Werror", "-pedantic",
        "-fsanitize=undefined", "-fno-sanitize-recover=all",
        "-I", str(root / "addon/include"), str(cpp), "-o", str(executable)
    ], check=True)
    subprocess.run([str(executable)], check=True)
