"""Compile the actual group recorder against a fake NGX/Direct3D backend.

This verifies recording logic and resource-state restoration, not Windows ABI,
driver compatibility, image quality, or real GPU synchronization.
Requires Python 3 and g++ (Linux). No NVIDIA DLL is executed.
"""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
source = (root / "addon/src/nr-standalone.cpp").read_text()
raw_start = source.index("static std::array<ID3D12Resource *, dlss5_aio_fg::kMaxGeneratedFrames>")
raw_end = source.index("static bool EnsureGeneratedOutputs", raw_start)
record_start = source.index("static UINT RecordFrameGenerationGroup(")
record_end = source.index("static void ResolveHandles", record_start)

preamble = r'''
#include "frame-generation-group.hpp"
#include <cassert>
#include <iostream>
#include <vector>
using UINT = unsigned int;
using DWORD = unsigned int;
using NVSDK_NGX_Result = unsigned int;
bool NVSDK_NGX_FAILED(unsigned int result) { return (result & 0xfff00000u) == 0xbad00000u; }
enum D3D12_RESOURCE_STATES { D3D12_RESOURCE_STATE_COMMON,
    D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE };
enum { D3D12_RESOURCE_BARRIER_TYPE_TRANSITION, D3D12_RESOURCE_BARRIER_TYPE_UAV };
struct ID3D12Resource { D3D12_RESOURCE_STATES state = D3D12_RESOURCE_STATE_COMMON; int value = 0; };
struct D3D12_RESOURCE_BARRIER {
    unsigned int Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    struct { ID3D12Resource *pResource = nullptr; } UAV;
    ID3D12Resource *resource = nullptr;
    D3D12_RESOURCE_STATES before = D3D12_RESOURCE_STATE_COMMON;
    D3D12_RESOURCE_STATES after = D3D12_RESOURCE_STATE_COMMON;
};
D3D12_RESOURCE_BARRIER Transition(ID3D12Resource *resource,
    D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after) {
    D3D12_RESOURCE_BARRIER barrier;
    barrier.resource = resource; barrier.before = before; barrier.after = after;
    return barrier;
}
struct ID3D12GraphicsCommandList {
    unsigned int uav_barriers = 0;
    void ResourceBarrier(unsigned int count, const D3D12_RESOURCE_BARRIER *barriers) {
        for (unsigned int i = 0; i < count; ++i) {
            const auto &b = barriers[i];
            if (b.Type == D3D12_RESOURCE_BARRIER_TYPE_UAV) { ++uav_barriers; continue; }
            assert(b.resource && b.resource->state == b.before);
            b.resource->state = b.after;
        }
    }
};
struct FakeComPtr { ID3D12Resource *pointer = nullptr; ID3D12Resource *Get() const { return pointer; } };
using GeneratedFrameOutputs = std::array<FakeComPtr, dlss5_aio_fg::kMaxGeneratedFrames>;
ID3D12GraphicsCommandList *g_active_neural_list = nullptr;
ID3D12Resource *current_output = nullptr;
unsigned int current_index = 0, fail_at = 0;
std::vector<unsigned int> indices;
std::vector<unsigned int> totals;
std::vector<bool> resets;
void SetFgEvaluationContract(ID3D12Resource *real, ID3D12Resource *output,
    ID3D12Resource *, ID3D12Resource *, bool reset, UINT count, UINT index) {
    assert(real->state == D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    assert(output->state == D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    current_output = output; current_index = index;
    indices.push_back(index); totals.push_back(count); resets.push_back(reset);
}
NVSDK_NGX_Result SafeEvaluateFg(DWORD *exception) {
    *exception = 0;
    assert(g_active_neural_list);
    if (current_index == fail_at) return 0xbad00005u;
    current_output->value = static_cast<int>(current_index);
    return 1;
}
'''

tests = r'''
int main() {
    for (auto real_state : {D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_UNORDERED_ACCESS}) {
        for (unsigned int count = 1; count <= 3; ++count) {
            for (unsigned int failure = 0; failure <= count; ++failure) {
                for (bool reset : {false, true}) {
                    ID3D12Resource real; real.state = real_state;
                    std::array<ID3D12Resource, 3> resources;
                    GeneratedFrameOutputs outputs = {{{&resources[0]}, {&resources[1]}, {&resources[2]}}};
                    ID3D12GraphicsCommandList commands, previous;
                    g_active_neural_list = &previous;
                    indices.clear(); totals.clear(); resets.clear(); fail_at = failure;
                    NVSDK_NGX_Result result = 0;
                    DWORD exception = 123;
                    auto completed = RecordFrameGenerationGroup(&commands, &real, outputs,
                        nullptr, nullptr, reset, real_state, count, result, exception);
                    assert(exception == 0 && g_active_neural_list == &previous);
                    assert(real.state == real_state);
                    for (const auto &resource : resources)
                        assert(resource.state == D3D12_RESOURCE_STATE_COMMON);
                    assert(completed == (failure ? 0 : count));
                    assert(NVSDK_NGX_FAILED(result) == (failure != 0));
                    const unsigned int calls = failure ? failure : count;
                    assert(indices.size() == calls);
                    for (unsigned int i = 0; i < calls; ++i) {
                        assert(indices[i] == i + 1 && totals[i] == count && resets[i] == reset);
                        if (!failure || i + 1 < failure) assert(resources[i].value == static_cast<int>(i + 1));
                    }
                    assert(commands.uav_barriers == (failure ? failure - 1 : count - 1));
                }
            }
        }
    }
    std::cout << "Actual recorder checks passed with fake backend\n";
}
'''

with tempfile.TemporaryDirectory(prefix="aio-fg-recorder-") as directory:
    cpp = Path(directory) / "recorder.cpp"
    exe = Path(directory) / "recorder"
    cpp.write_text(preamble + source[raw_start:raw_end] + source[record_start:record_end] + tests)
    subprocess.run(["g++", "-std=c++17", "-Wall", "-Wextra", "-Werror", "-pedantic",
        "-fsanitize=undefined", "-I", str(root / "addon/include"), str(cpp), "-o", str(exe)], check=True)
    subprocess.run([str(exe)], check=True)
