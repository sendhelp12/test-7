#include "../../addon/include/frame-generation-group.hpp"

#include <cassert>
#include <climits>
#include <iostream>
#include <vector>

int main()
{
    using namespace dlss5_aio_fg;
    assert(LimitGeneratedFrameCount(3, 1) == 1);
    assert(LimitGeneratedFrameCount(3, 2) == 2);
    assert(LimitGeneratedFrameCount(3, 3) == 3);
    assert(LimitGeneratedFrameCount(3, 5) == 3);
    assert(LimitGeneratedFrameCount(3, 0) == 1);
    assert(LimitGeneratedFrameCount(3, -1) == 1);
    assert(LimitGeneratedFrameCount(UINT_MAX, INT_MAX) == 3);
    assert(LimitGeneratedFrameCount(0, 3) == 1);

    int real = 100;
    std::array<int, kMaxGeneratedFrames> generated = {};
    std::array<int *, kMaxGeneratedFrames> outputs = {
        &generated[0], &generated[1], &generated[2]
    };
    for (unsigned int count = 1; count <= 3; ++count)
    {
        std::vector<unsigned int> calls;
        const unsigned int completed = EvaluateGroup(&real, outputs, count,
            [&](int *output, unsigned int index, unsigned int total) {
                assert(total == count);
                *output = static_cast<int>(index * 100 / (total + 1));
                calls.push_back(index);
                return true;
            });
        assert(completed == count && calls.size() == count);
        const auto presentation = PresentationOrder(&real, outputs, completed);
        assert(presentation.count == count + 1);
        for (unsigned int index = 0; index < count; ++index)
        {
            assert(calls[index] == index + 1);
            assert(presentation.sources[index] == outputs[index]);
            assert(*presentation.sources[index] < *presentation.sources[index + 1]);
        }
        assert(presentation.sources[count] == &real);
    }

    // A failure after writing a subframe must not expose that partial group.
    for (unsigned int fail_at = 1; fail_at <= 3; ++fail_at)
    {
        unsigned int calls = 0;
        const auto completed = EvaluateGroup(&real, outputs, 3,
            [&](int *, unsigned int index, unsigned int) {
                ++calls;
                return index != fail_at;
            });
        assert(completed == 0 && calls == fail_at);
        const auto presentation = PresentationOrder(&real, outputs, completed);
        assert(presentation.count == 1 && presentation.sources[0] == &real);
    }

    // Reject missing/aliased output buffers before invoking the backend.
    for (int invalid = 0; invalid < 5; ++invalid)
    {
        auto broken = outputs;
        unsigned int count = 3;
        if (invalid == 0) broken[1] = nullptr;
        if (invalid == 1) broken[1] = broken[0];
        if (invalid == 2) broken[2] = &real;
        if (invalid == 3) count = 0;
        if (invalid == 4) count = 4;
        unsigned int calls = 0;
        assert(EvaluateGroup(&real, broken, count,
            [&](int *, unsigned int, unsigned int) { ++calls; return true; }) == 0);
        assert(calls == 0);
        const auto presentation = PresentationOrder(&real, broken, count);
        assert(presentation.count == 1 && presentation.sources[0] == &real);
    }
    assert(PresentationOrder(static_cast<int *>(nullptr), outputs, 3).count == 0);

    // A queued group keeps its own count even after a newer group falls back.
    const auto queued4x = PresentationOrder(&real, outputs, 3);
    const auto fallback2x = PresentationOrder(&real, outputs, 1);
    assert(queued4x.count == 4 && fallback2x.count == 2);
    std::cout << "Frame-generation group checks passed\n";
}
