@echo off
setlocal
cd /d "%~dp0"
call "..\..\external\DLSS5-Feeder\tools\vcvars.bat" x64 || exit /b 1
if not exist build mkdir build
cl /nologo /std:c++17 /EHsc /W4 /WX frame-generation-group.cpp /Fo:build\frame-generation-group.obj /Fe:build\frame-generation-group.exe
if errorlevel 1 exit /b 1
build\frame-generation-group.exe
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /W4 /WX frame-generation-pacing.cpp /Fo:build\frame-generation-pacing.obj /Fe:build\frame-generation-pacing.exe
if errorlevel 1 exit /b 1
build\frame-generation-pacing.exe
exit /b %errorlevel%
