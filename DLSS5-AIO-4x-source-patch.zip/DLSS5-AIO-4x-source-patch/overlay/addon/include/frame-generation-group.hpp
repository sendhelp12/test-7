#pragma once

#include <algorithm>
#include <array>

// Platform-independent group rules shared by NGX recording and presentation.
// Counts describe extra frames: 1/2/3 generated frames mean 2x/3x/4x output.
namespace dlss5_aio_fg
{
inline constexpr unsigned int kMaxGeneratedFrames = 3;

inline unsigned int LimitGeneratedFrameCount(unsigned int requested, int runtime_max)
{
    if (runtime_max < 1) return 1;
    return std::min(std::clamp(requested, 1u, kMaxGeneratedFrames),
        static_cast<unsigned int>(runtime_max));
}

template <typename Resource>
bool ValidOutputs(Resource *real,
    const std::array<Resource *, kMaxGeneratedFrames> &outputs, unsigned int count)
{
    if (!real || count < 1 || count > kMaxGeneratedFrames) return false;
    for (unsigned int index = 0; index < count; ++index)
    {
        if (!outputs[index] || outputs[index] == real) return false;
        for (unsigned int prior = 0; prior < index; ++prior)
            if (outputs[index] == outputs[prior]) return false;
    }
    return true;
}

template <typename Resource, typename Evaluate>
unsigned int EvaluateGroup(Resource *real,
    const std::array<Resource *, kMaxGeneratedFrames> &outputs,
    unsigned int count, Evaluate evaluate)
{
    if (!ValidOutputs(real, outputs, count)) return 0;
    for (unsigned int index = 0; index < count; ++index)
        if (!evaluate(outputs[index], index + 1, count)) return 0;
    return count;
}

template <typename Resource>
struct PresentationGroup
{
    std::array<Resource *, kMaxGeneratedFrames + 1> sources = {};
    unsigned int count = 0;
};

template <typename Resource>
PresentationGroup<Resource> PresentationOrder(Resource *real,
    const std::array<Resource *, kMaxGeneratedFrames> &outputs, unsigned int count)
{
    PresentationGroup<Resource> result;
    if (!real) return result;
    if (ValidOutputs(real, outputs, count))
        for (unsigned int index = 0; index < count; ++index)
            result.sources[result.count++] = outputs[index];
    result.sources[result.count++] = real;
    return result;
}
}
