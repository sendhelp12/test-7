#pragma once

#include <algorithm>
#include <cstdint>

namespace dlss5_aio_fg
{
// Presenter-thread state only. Producer timestamps travel with each immutable
// output group; measuring the presenter's own service time would feed its waits
// back into the estimator and gradually slow the producer when the ring fills.
// All ticks use the same monotonic clock (QPC in the add-on).
class FrameGroupPacer
{
public:
    using Tick = std::int64_t;

    void Reset()
    {
        frequency_ = refresh_ = interval_ = period_ = 0;
        previous_submit_ = previous_begin_ = last_target_ = deadline_ = 0;
        count_ = samples_ = 0;
    }

    void BeginGroup(unsigned int count, Tick submitted, Tick now,
        Tick frequency, Tick refresh)
    {
        if (count < 2 || count > 4 || submitted <= 0 || now < submitted ||
            frequency <= 0 || refresh <= 0)
        {
            Reset();
            return;
        }

        // A pause, mode change, clock discontinuity or real-only fallback starts
        // a new timing history. Do not interpolate through a loading screen.
        const Tick discontinuity = std::max<Tick>(1, frequency / 2);
        if (count != count_ || frequency != frequency_ || refresh != refresh_ ||
            (previous_begin_ > 0 && (now < previous_begin_ ||
                now - previous_begin_ > discontinuity)) ||
            (previous_submit_ > 0 && (submitted <= previous_submit_ ||
                submitted - previous_submit_ > discontinuity)))
            Reset();

        frequency_ = frequency;
        refresh_ = refresh;
        count_ = count;
        const Tick minimum_period = refresh * count;
        // Bound deliberate delay even when processing is extremely slow. A
        // missing next group never holds a texture or waits on a producer here.
        const Tick maximum_period = std::max(refresh, frequency / 20) * count;
        if (previous_submit_ > 0)
        {
            const Tick sample = std::clamp(submitted - previous_submit_,
                minimum_period, maximum_period);
            if (samples_ == 0 || sample < period_)
                period_ = sample; // Recover promptly; avoid queuing old groups.
            else
                period_ += (sample - period_ + 3) / 4;
            if (samples_ < 1000000) ++samples_;
        }
        else
            period_ = minimum_period;

        interval_ = std::max(refresh, (period_ + count - 1) / count);
        // Keep an absolute timeline across frames and groups. Adding a full
        // interval after Present returns would accumulate draw/Present costs.
        deadline_ = last_target_ > 0 ?
            std::max(now, last_target_ + interval_) : now;
        previous_submit_ = submitted;
        previous_begin_ = now;
    }

    void Accepted(Tick now)
    {
        if (interval_ <= 0 || deadline_ <= 0) return;
        last_target_ = deadline_;
        // Only work that exceeds a whole OUTPUT interval gets a fresh schedule.
        // A 3 ms Present fits inside a 12.5 ms output interval even on a 240 Hz
        // display. Using half a physical refresh here repeatedly reanchored
        // ordinary Present calls and fed extra delay back into the output ring.
        if (now - deadline_ > interval_)
            last_target_ = now;
        deadline_ = last_target_ + interval_;
    }

    Tick Deadline() const { return deadline_; }
    Tick Interval() const { return interval_; }
    Tick GroupPeriod() const { return period_; }
    unsigned int Samples() const { return samples_; }

private:
    Tick frequency_ = 0, refresh_ = 0, interval_ = 0, period_ = 0;
    Tick previous_submit_ = 0, previous_begin_ = 0, last_target_ = 0, deadline_ = 0;
    unsigned int count_ = 0, samples_ = 0;
};
}
