# AIO v2.2.4 frame-generation update

Build identifier: **2.2.4-mfg-experimental.3**

This ZIP contains source changes. Build it with the accompanying
`DLSS5-AIO-online-build.yml` to obtain `standalone-dlssnr.addon64`.
The user has compiled and run experimental.1 and experimental.2. Their logs
confirm that 4x is active and that experimental.2 substantially improves the
reported presentation spacing. Experimental.3 corrects a remaining deadline
reset bug exposed by the new log. It passed the portable checks in
`VALIDATION.md`; its Windows build and in-game behavior still need validation.

## Experimental.3: normal Present time must not add another wait

The new `standalone-dlssnr(3).log` confirms experimental.2 is active. In the later
1080p-input section, median generated-to-real and real-to-next-generated
interval summaries are 12.187 ms and 12.971 ms. The previous capture showed
4.969 ms and 34.734 ms. These are separate runtime captures, not a controlled
benchmark or physical scanout measurement.

There is also a latency concern in the early near-native section: the reported
NGX-submit-to-presentation-entry delay is roughly 194 ms, compared with about
53 ms in the earlier capture. That metric includes processing and time waiting
for the presenter; it is not a measurement of total input-to-display latency.

Experimental.2 resets the next deadline whenever drawing/Present takes more
than half a monitor refresh (about 2.08 ms at 240 Hz). This capture shows
ordinary Present calls taking roughly 3 ms, which fit inside the adaptive
12–16 ms output interval. Repeated resets add unnecessary waits and can make
completed groups accumulate. This is consistent with the increased delay.

Experimental.3 preserves the absolute schedule for work that fits inside the
whole output interval. It reanchors only when the work exceeds that interval.
The new regression test fails with the old threshold and passes with the fix.
Longer 2.1/3.6/6 ms drawing/Present costs and exactly one-refresh work are tested.
The actual timer/accept functions also pass with a simulated 3.6 ms Present.
The effect on the real near-native queue delay has not yet been measured.

## Pacing correction retained from experimental.2

The supplied `standalone-dlssnr(2).log` confirms uneven presentation with the
automatic governor disabled. Later in the 1080p-input portion, generated-to-real
intervals are about 5 ms, while real-to-next-generated intervals are 32–36 ms.
These are CPU timestamps of accepted DXGI Present calls, not physical scanout.

The previous presenter used the monitor refresh interval for every subframe,
even when NGX processed source frames much slower. This update carries the
NGX submission timestamp with each output group, estimates production cadence,
and divides that period by the number of outputs. A 50 ms production interval
with four outputs gives a 12.5 ms target instead of releasing the group at the
240 Hz minimum.

Absolute deadlines keep ordinary drawing/Present costs inside each interval.
Timing history resets after long pauses, mode changes or real-only fallback.
The scheduler recovers quickly when production becomes faster, bounds deliberate
waits to 50 ms per output at 20 Hz or above, and checks shutdown even when a
deadline is already overdue. It works with diagnostic telemetry disabled.

The existing frame order, GPU fences, slot state transitions and completion
wakeups are retained. There is no new queue or wait for a future group. The
monitor refresh interval remains the floor and continues to control the
existing admission and FG-completion timeout calculations.

Spreading a group delays its final real frame compared with the old burst.
This is a pacing correction, not a Reflex implementation. NR still costs about
29–31 ms in the later supplied capture; this update cannot make that workload
produce 240 output FPS.

## Build online in your existing GitHub repository

1. Replace `DLSS5-AIO-4x-source-patch.zip` in the repository root with this ZIP.
2. Replace `.github/workflows/build.yml` with the accompanying updated
   `DLSS5-AIO-online-build.yml`. Replace both files together: the workflow checks
   the ZIP's SHA-256.
3. Open **Actions**, select **Build experimental DLSS5 AIO 4x**, then
   **Run workflow**.
4. Download the **DLSS5-AIO-4x-experimental-x64** artifact after a successful run.
5. Close the game, back up the working add-on, and replace
   `standalone-dlssnr.addon64` with the artifact's file.

The workflow retains the NGX/Vulkan dependency steps and compiler log capture.
It runs frame-group and pacing checks before building. Keep the existing
working ReShade, bridge and NVIDIA runtime setup.

## Confirm the update

The first log line must contain `2.2.4-mfg-experimental.3`. The existing
asynchronous presentation path should also log:

```text
frame-group cadence pacing active: producer submission intervals / output count; absolute deadlines, bounded waits
```

With **Collect performance telemetry** enabled, another line reports:

```text
performance group pacing: active=1 producer_period=...ms output_target=...ms samples=...
```

The target follows the processed cadence. Existing `generated->real` and
`real->generated` intervals should become closer during a steady scene. They
need not match during workload changes, loading, dropped groups or operating-
system scheduling delays. They do not prove physical scanout or image validity.

For comparison, keep **Adaptive GPU pressure governor** disabled and performance
telemetry enabled. The supplied capture still records about 120 game FPS, so
the requested diagnostic 30 FPS cap was not active. Reducing game load or NR
resolution can separately improve processing capacity.

The log is `%LOCALAPPDATA%\RHI\Logs\standalone-dlssnr.log`. It is overwritten
when the add-on attaches on the next launch.

## Multiplier settings

Use **Frame generation multiplier (restart required)** in ReShade. The INI
values under `[Standalone.DLSSNR]` remain:

| Setting | Requested output |
| --- | --- |
| `FrameGenerationMultiplier=0` | 2x: one generated + one real |
| `FrameGenerationMultiplier=1` | 3x: two generated + one real |
| `FrameGenerationMultiplier=2` | 4x: three generated + one real |

The runtime's maximum limits the active count. Every generated output has its
own texture. Incomplete groups are suppressed; a multi-frame rejection or
extra-output allocation failure schedules a controlled 2x fallback. Changing
the multiplier does not change NR pass count.

## Local Windows builds

Use Git, MSVC/Visual Studio 2022 Build Tools with Desktop development with C++,
a Windows SDK, the matching v2.2.4 checkout and its recursive submodules.
Populate NGX headers under `external/DLSS5-Feeder/external/ngx` and Vulkan plus
vk_video headers under `external/DLSS5-Feeder/external/vulkan`. The accompanying
workflow shows these dependency steps. From the extracted patch folder:

```powershell
.\Apply-And-Build.ps1 -SourceDirectory 'C:\src\DLSS5-Reshade-AIO'
```

The script verifies the base sources before copying the overlay and edits that
checkout. `-Include32Bit` additionally builds the existing wrapper/carrier;
32-bit runtime behavior has not been tested here.

`overlay` contains complete changed/new source files. `mfg-4x.patch` contains
the matching cumulative diff against the original uploaded v2.2.4 source,
including earlier compiler fixes. Both describe the same update.
